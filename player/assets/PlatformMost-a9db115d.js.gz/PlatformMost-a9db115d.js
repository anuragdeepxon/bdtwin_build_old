import{s as a,j as r}from"./index-ddca98b0.js";import{c as s,s as t}from"./safari-d06c6fd1.js";const e=a.div`
  background: var(--color-dark-gray);
  border-radius: 12px;
  width: 100%;
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  justify-content: center;
  flex-direction: column;
  gap: 4px;
  padding:16px 0;
  margin-top: 30px;
  a {
    text-decoration: underline;
  }
  p {
    margin: 0;
    display: flex;
    align-items: center;
    gap: 25px;
    margin-top: 5px;
  }
`,p=()=>r.jsxs(e,{children:[r.jsx("span",{children:"Our platform is most compatible with:"}),r.jsxs("p",{children:[r.jsx("img",{src:s,alt:"chrome"}),r.jsx("img",{src:t,alt:"safari"})]})]});export{p as default};
