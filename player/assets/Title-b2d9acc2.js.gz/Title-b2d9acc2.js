import{s as i,d as n,r as l,j as a}from"./index-ddca98b0.js";const x=i.h2`
  text-align: ${t=>(t==null?void 0:t.textAlign)||"left"};
  color: ${t=>(t==null?void 0:t.color)||"var(--color-white)"};
  font-size: ${t=>(t==null?void 0:t.fontSize)||"32px"};
  font-weight: ${t=>(t==null?void 0:t.fontWeigh)||"600"};
  line-height: ${t=>(t==null?void 0:t.lineHeight)||"42px"};
  @media ${n.mobileX} {
    
  
      font-size: 25px;
      line-height: 30px;
   
  }

`;function c(t,e){return t.title===e.title}const f=l.memo(t=>{const{title:e}=t;return a.jsx(x,{...t,children:e})},c);export{f as T};
