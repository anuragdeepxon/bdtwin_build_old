import{s as t,r as a,_ as o,j as s}from"./index-ddca98b0.js";import{T as i}from"./Title-b2d9acc2.js";const n=t.section`
  padding: 0 15px;
`,e=t.div`
  max-width: 1124px;
  width: 100%;
  padding: 24px 30px 106px 30px;
  margin: 0 auto;
  position: relative;
  margin-top: 60px;
  margin-bottom: 60px;
  background-color: #151515;
  border-radius: 8px;
`,p=a.lazy(()=>o(()=>import("./TransactionsTable-add49aa5.js"),["assets/TransactionsTable-add49aa5.js","assets/index-ddca98b0.js","assets/Pagination.styles-bbf35878.js","assets/Pagination-57f3c502.js"])),x=r=>s.jsx(a.Suspense,{fallback:null,children:s.jsx(p,{...r})}),c=()=>s.jsx(n,{children:s.jsxs(e,{children:[s.jsx(i,{title:"TRANSACTIONS"}),s.jsx(x,{})]})});export{c as default};
